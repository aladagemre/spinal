#include "common.h"

//global score optimization function
void optimize_global_score(array2<double>*, array2<double>*, graph, graph, double, char*);
//global score optimization function
void optimize_global_score2(array2<double>*, array2<double>*, graph, graph, double, char*);
