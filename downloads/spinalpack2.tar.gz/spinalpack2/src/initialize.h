#include "common.h"

//construct similarity matrix from file
void construct_simmatrix(array2<double>*, char*);
//initialize cur matrix
void init_cur(array2<double>*, array2<double>*, graph, graph, double);
