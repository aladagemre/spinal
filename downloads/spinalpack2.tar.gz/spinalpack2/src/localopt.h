#include "common.h"

//local score optimization functions
void optimize_local_score(array2<double>*, array2<double>*, graph, graph, double, int, int, bool);

